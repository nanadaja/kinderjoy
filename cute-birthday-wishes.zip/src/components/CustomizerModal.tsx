import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, Copy, Check, QrCode, Heart, Link, Edit3, Image } from 'lucide-react';
import { BirthdayConfig, PHOTO_PRESETS, PresetPhotoId } from '../types';

interface CustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentConfig: BirthdayConfig;
  onSave: (newConfig: BirthdayConfig) => void;
}

export const CustomizerModal: React.FC<CustomizerModalProps> = ({
  isOpen,
  onClose,
  currentConfig,
  onSave,
}) => {
  const [recipientName, setRecipientName] = useState(currentConfig.recipientName);
  const [senderName, setSenderName] = useState(currentConfig.senderName);
  const [message, setMessage] = useState(currentConfig.message);
  const [date, setDate] = useState(currentConfig.date);
  const [photos, setPhotos] = useState<string[]>([...currentConfig.photos]);
  const [selectedPresetIndex, setSelectedPresetIndex] = useState<number | null>(null);

  const [copied, setCopied] = useState(false);
  const [generatedUrl, setGeneratedUrl] = useState('');

  // Encode configurations safely to base64
  const generateShareLink = () => {
    const configToShare: BirthdayConfig = {
      recipientName,
      senderName,
      message,
      date,
      photos,
      presetMusicTempo: currentConfig.presetMusicTempo,
      themeColor: currentConfig.themeColor,
    };

    const jsonStr = JSON.stringify(configToShare);
    // Safe base64 encoding for unicode
    const b64 = btoa(encodeURIComponent(jsonStr).replace(/%([0-9A-F]{2})/g, (match, p1) => {
      return String.fromCharCode(parseInt(p1, 16));
    }));

    const url = new URL(window.location.href);
    url.searchParams.set('gift', b64);
    
    // Also update current app's live configuration
    onSave(configToShare);

    const fullUrl = url.toString();
    setGeneratedUrl(fullUrl);
    return fullUrl;
  };

  const handleCopy = async () => {
    const url = generateShareLink();
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      // Fallback
      const input = document.createElement('input');
      input.value = url;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSelectPreset = (photoIdx: number, url: string) => {
    const newPhotos = [...photos];
    newPhotos[photoIdx] = url;
    setPhotos(newPhotos);
    setSelectedPresetIndex(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div id="customizer-modal-backdrop" className="fixed inset-0 z-50 overflow-y-auto bg-[#050B1F]/90 backdrop-blur-md flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            className="relative bg-slate-950/90 backdrop-blur-2xl border border-white/10 rounded-[35px] w-full max-w-lg shadow-2xl p-6 text-slate-100 overflow-hidden"
          >
            {/* Background ambient light */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-4">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-sky-400 animate-pulse" />
                <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-pink-300 to-yellow-100 drop-shadow-[0_0_8px_rgba(147,197,253,0.3)]">Kustomisasi Kado Kamu 🎁</h2>
              </div>
              <button
                id="btn-close-customizer"
                onClick={onClose}
                className="p-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-slate-400 hover:text-white active:scale-90 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
              {/* Recipient Name */}
              <div>
                <label className="block text-[11px] font-black text-sky-300 uppercase tracking-wider mb-1.5">
                  Nama Penerima Ulang Tahun 🎈
                </label>
                <input
                  id="input-recipient-name"
                  type="text"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  placeholder="Contoh: Rania Anindita"
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl focus:border-sky-400 focus:ring-1 focus:ring-sky-400 outline-none text-sm text-slate-100 placeholder-slate-400 transition-all"
                />
              </div>

              {/* Sender Name */}
              <div>
                <label className="block text-[11px] font-black text-sky-300 uppercase tracking-wider mb-1.5">
                  Nama Pengirim 💖
                </label>
                <input
                  id="input-sender-name"
                  type="text"
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="Contoh: Sahabat Terbaikmu"
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl focus:border-sky-400 focus:ring-1 focus:ring-sky-400 outline-none text-sm text-slate-100 placeholder-slate-400 transition-all"
                />
              </div>

              {/* Custom Wishes Message */}
              <div>
                <label className="block text-[11px] font-black text-sky-300 uppercase tracking-wider mb-1.5">
                  Pesan Ucapan Spesial ✨
                </label>
                <textarea
                  id="input-wish-message"
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tuliskan ucapan termanis kamu..."
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl focus:border-sky-400 focus:ring-1 focus:ring-sky-400 outline-none text-sm text-slate-100 placeholder-slate-400 transition-all resize-none"
                />
              </div>

              {/* Custom Date */}
              <div>
                <label className="block text-[11px] font-black text-sky-300 uppercase tracking-wider mb-1.5">
                  Tanggal Ulang Tahun
                </label>
                <input
                  id="input-birth-date"
                  type="text"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  placeholder="Contoh: 15 Juli 2026"
                  className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl focus:border-sky-400 focus:ring-1 focus:ring-sky-400 outline-none text-sm text-slate-100 placeholder-slate-400 transition-all"
                />
              </div>

              {/* Photos personalization presets */}
              <div>
                <label className="block text-xs font-bold text-sky-300 uppercase tracking-wide mb-1.5">
                  Ganti Foto-Foto Galeri 📸
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {photos.map((photoUrl, photoIdx) => (
                    <div key={photoIdx} className="relative group">
                      <div className="aspect-square rounded-xl bg-slate-950 overflow-hidden border border-slate-800">
                        <img src={photoUrl} alt="Thumbnail" className="w-full h-full object-cover" />
                      </div>
                      <button
                        id={`btn-choose-preset-${photoIdx}`}
                        onClick={() => setSelectedPresetIndex(photoIdx)}
                        className="absolute inset-0 bg-slate-950/80 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-[10px] text-sky-300 transition-all font-semibold rounded-xl"
                      >
                        <Image className="w-4 h-4 mb-0.5 text-sky-400" />
                        Ganti Foto
                      </button>
                    </div>
                  ))}
                </div>

                {/* Sub-presets dropdown / selector */}
                <AnimatePresence>
                  {selectedPresetIndex !== null && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 p-3 bg-slate-950 rounded-2xl border border-sky-500/20"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] font-bold text-sky-300 uppercase">Pilih Gambar Lucu Preset:</span>
                        <button
                          onClick={() => setSelectedPresetIndex(null)}
                          className="text-[10px] text-rose-400 font-bold"
                        >
                          Tutup
                        </button>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {Object.entries(PHOTO_PRESETS).map(([key, item]) => (
                          <button
                            key={key}
                            onClick={() => handleSelectPreset(selectedPresetIndex, item.url)}
                            className="flex flex-col items-center p-1.5 rounded-xl border border-slate-800 hover:border-sky-500/50 bg-slate-900 text-[10px] text-slate-300 font-medium active:scale-95 transition-all text-center"
                          >
                            <img src={item.url} alt={item.title} className="w-full aspect-video object-cover rounded-lg mb-1" />
                            {item.title}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Dynamic Generated Link & Live QR Code */}
            <div className="mt-6 pt-4 border-t border-white/10">
              <button
                id="btn-generasikan-link"
                onClick={generateShareLink}
                className="w-full py-3 bg-gradient-to-r from-blue-400 via-sky-400 to-pink-400 hover:from-blue-300 hover:to-pink-300 text-slate-950 font-black text-sm rounded-full flex items-center justify-center gap-2 active:scale-[0.98] transition-all uppercase tracking-wider shadow-lg"
              >
                <Sparkles className="w-4 h-4" />
                Simpan & Buat Link Baru 🎁
              </button>

              {generatedUrl && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-5 bg-white/5 rounded-[25px] border border-white/10 flex flex-col items-center text-center"
                >
                  <span className="text-xs font-bold text-sky-300 flex items-center gap-1 mb-2">
                    <Link className="w-3.5 h-3.5" />
                    Link Kamu Sudah Siap!
                  </span>

                  {/* QR Code generator */}
                  <div className="bg-white p-3 rounded-[25px] mb-3 shadow-2xl border border-white/20">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(generatedUrl)}`}
                      alt="QR Code"
                      className="w-36 h-36"
                    />
                  </div>
                  <p className="text-[10px] text-slate-300 mb-3 max-w-[280px]">
                    Scan QR Code di atas dengan HP untuk langsung membuka ucapan versi kamu! Atau salin link di bawah ini.
                  </p>

                  <div className="flex gap-2 w-full">
                    <button
                      id="btn-salin-link-kado"
                      onClick={handleCopy}
                      className="flex-1 py-2.5 px-3 bg-white/5 border border-white/10 hover:bg-white/10 text-sky-200 text-xs font-bold rounded-full flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-400" />
                          <span className="text-emerald-400">Tersalin!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          Salin Link Ucapan
                        </>
                      )}
                    </button>
                    <a
                      href={`https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(generatedUrl)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 px-3 bg-white/5 border border-white/10 hover:bg-white/10 text-slate-300 hover:text-white text-xs font-bold rounded-full flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                    >
                      <QrCode className="w-4 h-4 text-indigo-400" />
                      QR Besar
                    </a>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
