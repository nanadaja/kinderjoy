import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface ParticleLayerProps {
  burstTrigger: number;
  balloonTrigger: number;
}

interface ConfettiPiece {
  id: number;
  x: number;
  y: number;
  color: string;
  size: number;
  angle: number;
  spin: number;
  delay: number;
}

interface BalloonPiece {
  id: number;
  x: number;
  color: string;
  size: number;
  speed: number;
  wiggleSpeed: number;
}

const COLORS = [
  '#38bdf8', // sky blue
  '#60a5fa', // blue
  '#f43f5e', // pink
  '#fbbf24', // yellow
  '#a855f7', // purple
  '#34d399', // emerald
  '#fb7185', // rose pastel
];

export const ParticleLayer: React.FC<ParticleLayerProps> = ({ burstTrigger, balloonTrigger }) => {
  const [confettis, setConfettis] = useState<ConfettiPiece[]>([]);
  const [balloons, setBalloons] = useState<BalloonPiece[]>([]);

  // Trigger confetti burst
  useEffect(() => {
    if (burstTrigger === 0) return;

    // Create 60 confetti pieces blasting out from the bottom/center
    const pieces: ConfettiPiece[] = Array.from({ length: 65 }).map((_, i) => {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 250 + 100;
      return {
        id: Date.now() + i + Math.random(),
        // start near bottom or middle
        x: 50 + (Math.random() - 0.5) * 20, // percent
        y: 80 + (Math.random() - 0.5) * 10, // percent
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        size: Math.random() * 10 + 6,
        angle: angle,
        spin: Math.random() * 360,
        delay: Math.random() * 0.15,
      };
    });

    setConfettis((prev) => [...prev, ...pieces]);

    // Cleanup after animation completes
    const timer = setTimeout(() => {
      setConfettis((prev) => prev.slice(65));
    }, 4500);

    return () => clearTimeout(timer);
  }, [burstTrigger]);

  // Trigger floating balloons
  useEffect(() => {
    if (balloonTrigger === 0) return;

    // Send 12 beautiful colorful balloons floating up
    const newBalloons: BalloonPiece[] = Array.from({ length: 14 }).map((_, i) => ({
      id: Date.now() + i + Math.random(),
      x: Math.random() * 85 + 5, // percent width
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      size: Math.random() * 30 + 40, // width in px
      speed: Math.random() * 4 + 3, // speed seconds
      wiggleSpeed: Math.random() * 2 + 1,
    }));

    setBalloons((prev) => [...prev, ...newBalloons]);

    // Clean up balloons after they fly off the screen
    const timer = setTimeout(() => {
      setBalloons((prev) => prev.slice(14));
    }, 8000);

    return () => clearTimeout(timer);
  }, [balloonTrigger]);

  return (
    <div id="particle-layer" className="absolute inset-0 overflow-hidden pointer-events-none z-40">
      {/* Confetti Explosion */}
      <AnimatePresence>
        {confettis.map((c) => {
          const destinationX = Math.cos(c.angle) * (Math.random() * 25 + 15); // delta x
          const destinationY = -Math.random() * 65 - 15; // float up delta y
          return (
            <motion.div
              key={c.id}
              initial={{ 
                opacity: 1, 
                x: c.x + '%', 
                y: c.y + 'vh', 
                scale: 0.1, 
                rotate: 0 
              }}
              animate={{
                opacity: [1, 1, 0.8, 0],
                x: `calc(${c.x}% + ${destinationX}vw)`,
                y: `calc(${c.y}vh + ${destinationY}vh)`,
                scale: [0.2, 1.2, 0.9, 0.6],
                rotate: c.spin * 4,
              }}
              exit={{ opacity: 0 }}
              transition={{ 
                duration: 2.8 + Math.random() * 1.2, 
                ease: 'easeOut',
                delay: c.delay
              }}
              className="absolute rounded-sm"
              style={{
                width: c.size,
                height: c.size * (Math.random() > 0.5 ? 1.5 : 0.6),
                backgroundColor: c.color,
                borderRadius: Math.random() > 0.7 ? '50%' : '2px',
                boxShadow: `0 2px 6px ${c.color}50`,
              }}
            />
          );
        })}
      </AnimatePresence>

      {/* Floating Balloons */}
      <AnimatePresence>
        {balloons.map((b) => (
          <motion.div
            key={b.id}
            initial={{ y: '110vh', x: b.x + '%', opacity: 0 }}
            animate={{
              y: '-20vh',
              opacity: [0, 1, 1, 0.8, 0],
              x: [
                b.x + '%',
                b.x + 8 + '%',
                b.x - 8 + '%',
                b.x + 4 + '%',
              ],
            }}
            exit={{ opacity: 0 }}
            transition={{
              duration: b.speed,
              ease: 'linear',
            }}
            className="absolute flex flex-col items-center"
            style={{ width: b.size }}
          >
            {/* Balloon Bulb */}
            <div
              className="relative rounded-full aspect-[5/6] w-full flex items-center justify-center shadow-lg"
              style={{
                backgroundColor: b.color,
                boxShadow: `inset -6px -10px 20px rgba(0,0,0,0.2), 0 10px 20px ${b.color}40`,
                borderRadius: '50% 50% 50% 50% / 40% 40% 60% 60%',
              }}
            >
              {/* Glossy reflection bubble */}
              <div className="absolute top-[10%] left-[15%] w-[25%] h-[15%] bg-white/40 rounded-full rotate-[-30deg]" />
              
              {/* Adorable emoticon eyes and smile on some balloons */}
              {b.size > 55 && (
                <div className="flex flex-col items-center gap-0.5 opacity-70">
                  <div className="flex gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-900" />
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-900" />
                  </div>
                  <span className="w-3 h-1.5 border-b-2 border-slate-900 rounded-b-full" />
                </div>
              )}
            </div>

            {/* Balloon Knot */}
            <div
              className="w-3 h-2 -mt-0.5 rotate-180"
              style={{
                borderBottom: `6px solid ${b.color}`,
                borderLeft: '4px solid transparent',
                borderRight: '4px solid transparent',
              }}
            />

            {/* Balloon Thread */}
            <svg className="w-2 h-14 overflow-visible" viewBox="0 0 10 50">
              <path
                d="M5,0 Q8,12 2,25 T5,50"
                fill="none"
                stroke="rgba(255,255,255,0.4)"
                strokeWidth="1.5"
              />
            </svg>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};
