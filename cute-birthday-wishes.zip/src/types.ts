export interface BirthdayConfig {
  recipientName: string;
  senderName: string;
  message: string;
  date: string;
  photos: string[]; // URLs, base64 strings, or preset IDs
  presetMusicTempo: number; // For synth speed
  themeColor: string; // "blue", "cyan", "purple"
}

export type PresetPhotoId = 'ewi-5' | 'ewi-6' | 'ewii-8' | 'rania-friend' | 'cat-cute' | 'cake' | 'bear-balloon' | 'stars-night' | 'gift-box';

export const PHOTO_PRESETS: Record<PresetPhotoId, { title: string; url: string }> = {
  'ewi-5': {
    title: 'Ewi 5',
    url: '/src/assets/images/ewi_5.jpeg',
  },
  'ewi-6': {
    title: 'Ewi 6',
    url: '/src/assets/images/ewi_6.jpeg',
  },
  'ewii-8': {
    title: 'Ewi 8',
    url: '/src/assets/images/ewii_8.jpeg',
  },
  'rania-friend': {
    title: 'Sahabat Terbaik',
    url: '/src/assets/images/rania_and_friend_1783912644381.jpg',
  },
  'cat-cute': {
    title: 'Kucing Imut',
    url: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
  },
  'cake': {
    title: 'Kue Enak',
    url: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
  },
  'bear-balloon': {
    title: 'Balon Ceria',
    url: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
  },
  'stars-night': {
    title: 'Langit Malam',
    url: 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
  },
  'gift-box': {
    title: 'Kado Misteri',
    url: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
  },
};
