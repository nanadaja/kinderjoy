import React from 'react';
import { motion } from 'motion/react';
import { Gift, Sparkles, Heart } from 'lucide-react';

interface OpeningScreenProps {
  recipientName: string;
  onOpen: () => void;
}

export const OpeningScreen: React.FC<OpeningScreenProps> = ({ recipientName, onOpen }) => {
  return (
    <div id="opening-screen" className="relative flex flex-col items-center justify-center min-h-[100dvh] w-full bg-[#050B1F] overflow-hidden px-6 text-center select-none">
      {/* Background glowing gradients from Artistic Flair theme */}
      <div className="absolute -top-10 left-10 w-44 h-52 bg-blue-500 rounded-full opacity-25 blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-10 right-10 w-52 h-64 bg-pink-500 rounded-full opacity-20 blur-3xl pointer-events-none"></div>

      {/* Aesthetic wireframe outlines */}
      <div className="absolute top-20 left-1/4 w-32 h-32 border-2 border-blue-400/20 rounded-full pointer-events-none"></div>
      <div className="absolute bottom-20 right-1/3 w-48 h-48 border-2 border-pink-400/10 rounded-full pointer-events-none"></div>

      {/* Sparkling symbols from template */}
      <div className="absolute inset-0 pointer-events-none opacity-80">
        <div className="absolute top-10 left-10 text-blue-300 text-2xl animate-twinkle-star">✦</div>
        <div className="absolute top-1/4 right-20 text-blue-200 text-xl animate-twinkle-star" style={{ animationDelay: '1s' }}>★</div>
        <div className="absolute bottom-1/3 left-20 text-pink-300 text-lg animate-twinkle-star" style={{ animationDelay: '1.5s' }}>✦</div>
        <div className="absolute bottom-20 right-40 text-yellow-200 text-2xl animate-twinkle-star" style={{ animationDelay: '2s' }}>★</div>
        <div className="absolute top-20 right-1/4 w-3 h-3 bg-pink-400 rounded-full blur-sm"></div>
        <div className="absolute top-1/2 left-10 w-2 h-2 bg-blue-400 rounded-full blur-[1px]"></div>
      </div>

      {/* Twinkling ambient small particles */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-sky-200 animate-pulse-slow"
            style={{
              width: Math.random() * 3 + 2 + 'px',
              height: Math.random() * 3 + 2 + 'px',
              top: Math.random() * 100 + '%',
              left: Math.random() * 100 + '%',
              animationDelay: Math.random() * 3 + 's',
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: 'easeOut' }}
        className="z-10 flex flex-col items-center max-w-sm"
      >
        {/* Adorable little banner badge */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-white/5 backdrop-blur-md border border-white/10 text-sky-300 text-xs font-semibold tracking-wide shadow-lg mb-6"
        >
          <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
          Kirim Paket Kado Spesial
          <Heart className="w-3 h-3 text-rose-400 fill-rose-400" />
        </motion.div>

        {/* Floating title */}
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-blue-300 text-xs tracking-widest uppercase font-bold mb-3"
        >
          ✦ Halo Teman! Ada kejutan untuk ✦
        </motion.h2>

        {/* Artistic Flair giant name gradient */}
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, type: 'spring', stiffness: 100 }}
          className="relative inline-block mb-12"
        >
          <h1 className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-200 via-pink-300 to-yellow-100 drop-shadow-[0_0_20px_rgba(147,197,253,0.6)] py-2 uppercase tracking-wide">
            {recipientName || 'Kamu'}
          </h1>
          <div className="absolute -top-6 -right-6 w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center text-black text-xl rotate-12 shadow-lg">🎈</div>
        </motion.div>

        {/* Glowing Interactive Gift / Envelope Box */}
        <motion.div
          id="gift-box-container"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="relative cursor-pointer mb-12 group"
          onClick={onOpen}
        >
          {/* Outer glowing halo */}
          <div className="absolute -inset-4 bg-sky-500/20 rounded-full blur-xl group-hover:bg-sky-400/30 transition-all duration-300 animate-pulse" />

          {/* Floating gift container */}
          <motion.div
            animate={{
              y: [0, -12, 0],
              rotate: [0, -3, 3, -3, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative flex items-center justify-center w-40 h-40 bg-gradient-to-tr from-sky-600 via-sky-400 to-indigo-500 rounded-[40px] shadow-[0_15px_40px_rgba(5,11,31,0.5)] border-4 border-white/20"
          >
            {/* Elegant ribbon lines */}
            <div className="absolute w-6 h-full bg-yellow-300" />
            <div className="absolute w-full h-6 bg-yellow-300" />
            
            {/* Ribbons bow */}
            <div className="absolute -top-4 w-12 h-12 border-4 border-yellow-300 rounded-full bg-gradient-to-br from-yellow-200 to-yellow-400 shadow-md rotate-45 transform -translate-x-1/2 left-1/2" style={{ top: '-14px', width: '36px', height: '36px', borderRadius: '50% 50% 0 50%' }} />
            <div className="absolute -top-4 w-12 h-12 border-4 border-yellow-300 rounded-full bg-gradient-to-br from-yellow-200 to-yellow-400 shadow-md -rotate-45 transform -translate-x-1/2 left-1/2" style={{ top: '-14px', width: '36px', height: '36px', borderRadius: '50% 50% 50% 0' }} />

            <Gift className="w-16 h-16 text-white drop-shadow-md z-10" />

            <span className="absolute bottom-3 text-[10px] font-bold text-yellow-900 tracking-wider bg-yellow-300 px-2.5 py-0.5 rounded-full z-10">
              TAP ME!
            </span>
          </motion.div>
        </motion.div>

        {/* Call to action message */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 0] }}
          transition={{
            duration: 2.5,
            repeat: Infinity,
            delay: 1,
          }}
          className="text-sky-300/80 text-xs font-bold tracking-widest uppercase mb-6"
        >
          ✨ Sentuh kado di atas untuk membuka! ✨
        </motion.p>

        {/* Explicit Button */}
        <motion.button
          id="btn-buka-kado"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onOpen}
          className="px-8 py-4 bg-gradient-to-r from-blue-400 via-sky-400 to-pink-400 hover:from-blue-300 hover:to-pink-300 text-slate-950 font-bold text-base rounded-full shadow-2xl active:translate-y-0.5 transition-all duration-200 uppercase tracking-wider"
        >
          Buka Kado Spesial 🎁
        </motion.button>
      </motion.div>
    </div>
  );
};
