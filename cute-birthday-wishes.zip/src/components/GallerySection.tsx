import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Maximize2, X, Sparkles, Heart } from 'lucide-react';

interface GallerySectionProps {
  photos: string[];
  onChangePhoto: (index: number, newUrl: string) => void;
}

export const GallerySection: React.FC<GallerySectionProps> = ({ photos, onChangePhoto }) => {
  const [activePhoto, setActivePhoto] = useState<{ url: string; index: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  // Simple base64 image upload handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (editingIndex === null || !e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onChangePhoto(editingIndex, reader.result);
      }
      setEditingIndex(null);
    };
    reader.readAsDataURL(file);
  };

  const triggerUpload = (index: number) => {
    setEditingIndex(index);
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div id="gallery-section" className="relative flex flex-col items-center bg-white/5 backdrop-blur-xl border border-white/10 rounded-[35px] p-6 shadow-2xl max-w-md w-full mx-auto">
      {/* Invisible file uploader input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Decorative stars banner */}
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-gradient-to-r from-blue-400 via-sky-400 to-pink-400 border border-white/10 text-slate-950 text-xs font-black uppercase tracking-wider rounded-full shadow-lg flex items-center gap-1">
        <Heart className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
        Galeri Foto Memori
      </div>

      <div className="text-center mt-2 mb-6">
        <h3 className="text-lg font-bold text-sky-200 flex items-center justify-center gap-1.5">
          Momen Indah Kita ✨
        </h3>
        <p className="text-xs text-sky-300/70 mt-1">
          Ketuk foto untuk memperbesar, atau ketuk tombol kamera untuk mengganti foto kamu sendiri!
        </p>
      </div>

      {/* Grid of Polaroid Cards */}
      <div className="grid grid-cols-1 xs:grid-cols-2 gap-4 w-full">
        {photos.map((photoUrl, idx) => (
          <motion.div
            key={idx}
            whileHover={{ scale: 1.02, rotate: idx % 2 === 0 ? 1 : -1 }}
            className="bg-white p-3 pb-6 rounded-xl shadow-lg border border-slate-200/20 transform flex flex-col items-center select-none cursor-pointer text-slate-800"
          >
            {/* Polaroid image container */}
            <div 
              className="relative w-full aspect-square bg-slate-100 rounded-lg overflow-hidden group"
              onClick={() => setActivePhoto({ url: photoUrl, index: idx })}
            >
              <img
                src={photoUrl}
                alt={`Memory ${idx + 1}`}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
              {/* Desktop hover actions overlay */}
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActivePhoto({ url: photoUrl, index: idx });
                  }}
                  className="p-2.5 bg-white/20 hover:bg-white/40 backdrop-blur-md text-white rounded-full transition-all hover:scale-110"
                  title="Perbesar Foto"
                >
                  <Maximize2 className="w-5 h-5 drop-shadow-md" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    triggerUpload(idx);
                  }}
                  className="p-2.5 bg-white/20 hover:bg-white/40 backdrop-blur-md text-white rounded-full transition-all hover:scale-110"
                  title="Ganti Foto"
                >
                  <Camera className="w-5 h-5 drop-shadow-md" />
                </button>
              </div>
              
              {/* Always visible on mobile, hover-triggered on desktop */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  triggerUpload(idx);
                }}
                className="absolute top-2 right-2 p-2 bg-slate-950/80 backdrop-blur-md text-white border border-white/10 rounded-full shadow-lg active:scale-90 transition-all md:opacity-0 md:group-hover:opacity-100 duration-200 z-10 hover:bg-sky-500 hover:text-slate-950"
                title="Ganti Foto"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Polaroid text footer */}
            <div className="mt-3 w-full flex items-center justify-between px-1">
              <span className="font-mono text-xs text-slate-500 font-bold tracking-wide">
                Momen #0{idx + 1} 🎈
              </span>
              
              {/* Camera trigger to personalize */}
              <button
                id={`btn-ganti-foto-${idx}`}
                onClick={(e) => {
                  e.stopPropagation();
                  triggerUpload(idx);
                }}
                className="p-1 rounded-lg bg-sky-100 hover:bg-sky-200 text-sky-700 active:scale-95 transition-all"
                title="Ganti Foto"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Lightbox Modal (Full Screen) */}
      <AnimatePresence>
        {activePhoto && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/95 z-50 flex items-center justify-center p-6"
            onClick={() => setActivePhoto(null)}
          >
            {/* Close trigger */}
            <button
              id="btn-close-lightbox"
              onClick={() => setActivePhoto(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Giant polaroid card in lightbox */}
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white p-4 pb-12 rounded-2xl shadow-2xl max-w-md w-full text-slate-800"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative w-full aspect-square bg-slate-100 rounded-xl overflow-hidden mb-4">
                <img
                  src={activePhoto.url}
                  alt="Expanded Memory"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="text-center font-mono text-sm text-slate-600 font-bold flex items-center justify-center gap-1">
                <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
                Memory Box #{activePhoto.index + 1}
                <Sparkles className="w-4 h-4 text-amber-500 fill-amber-500" />
              </div>
              <div className="text-center text-xs text-slate-400 mt-2 font-mono">
                "Setiap detik bersamamu adalah kado terindah."
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
