/**
 * Web Audio API retro 8-bit chiptune music engine for Happy Birthday melody
 */

// Define note frequencies in Hz
const NOTES: Record<string, number> = {
  'G4': 392.00,
  'A4': 440.00,
  'B4': 493.88,
  'C5': 523.25,
  'D5': 587.33,
  'E5': 659.25,
  'F5': 698.46,
  'G5': 783.99,
  'SILENCE': 0,
};

interface MelodyNote {
  note: string;
  duration: number; // in beats
}

const MELODY: MelodyNote[] = [
  { note: 'G4', duration: 0.75 },
  { note: 'G4', duration: 0.25 },
  { note: 'A4', duration: 1.0 },
  { note: 'G4', duration: 1.0 },
  { note: 'C5', duration: 1.0 },
  { note: 'B4', duration: 2.0 },
  
  { note: 'G4', duration: 0.75 },
  { note: 'G4', duration: 0.25 },
  { note: 'A4', duration: 1.0 },
  { note: 'G4', duration: 1.0 },
  { note: 'D5', duration: 1.0 },
  { note: 'C5', duration: 2.0 },
  
  { note: 'G4', duration: 0.75 },
  { note: 'G4', duration: 0.25 },
  { note: 'G5', duration: 1.0 },
  { note: 'E5', duration: 1.0 },
  { note: 'C5', duration: 1.0 },
  { note: 'B4', duration: 1.0 },
  { note: 'A4', duration: 2.0 },
  
  { note: 'F5', duration: 0.75 },
  { note: 'F5', duration: 0.25 },
  { note: 'E5', duration: 1.0 },
  { note: 'C5', duration: 1.0 },
  { note: 'D5', duration: 1.0 },
  { note: 'C5', duration: 2.0 },
  
  { note: 'SILENCE', duration: 1.5 }, // small pause before looping
];

export class BirthdaySynth {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private currentTimeout: number | null = null;
  private noteIndex = 0;
  private bpm = 120;
  private volumeNode: GainNode | null = null;

  constructor() {
    // Lazy initialize to avoid browser console warnings about auto-play
  }

  private initAudio() {
    if (this.ctx) return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    this.ctx = new AudioContextClass();
    
    this.volumeNode = this.ctx.createGain();
    this.volumeNode.gain.setValueAtTime(0.12, this.ctx.currentTime); // Gentle volume by default
    this.volumeNode.connect(this.ctx.destination);
  }

  public play(onNoteChange?: (noteName: string) => void) {
    this.initAudio();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    if (this.isPlaying) return;
    this.isPlaying = true;
    this.playNextNote(onNoteChange);
  }

  private playNextNote(onNoteChange?: (noteName: string) => void) {
    if (!this.isPlaying || !this.ctx || !this.volumeNode) return;

    const currentNote = MELODY[this.noteIndex];
    const freq = NOTES[currentNote.note];
    const beatDuration = 60 / this.bpm;
    const duration = currentNote.duration * beatDuration;

    if (freq > 0) {
      // Create oscillator for the 8-bit chiptune retro square wave vibe
      const osc = this.ctx.createOscillator();
      const gainNode = this.ctx.createGain();

      // Use a custom square or triangle wave for that classic adorable retro feel
      osc.type = 'triangle'; // triangle is softer and cuter than square
      osc.frequency.value = freq;

      // Gentle attack and decay to prevent harsh pops
      gainNode.gain.setValueAtTime(0, this.ctx.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.8, this.ctx.currentTime + 0.05);
      gainNode.gain.setValueAtTime(0.8, this.ctx.currentTime + duration - 0.05);
      gainNode.gain.linearRampToValueAtTime(0, this.ctx.currentTime + duration);

      osc.connect(gainNode);
      gainNode.connect(this.volumeNode);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);

      if (onNoteChange) {
        onNoteChange(currentNote.note);
      }
    } else {
      if (onNoteChange) {
        onNoteChange('🎵');
      }
    }

    // Schedule next note
    this.noteIndex = (this.noteIndex + 1) % MELODY.length;
    this.currentTimeout = window.setTimeout(() => {
      this.playNextNote(onNoteChange);
    }, duration * 1000);
  }

  public pause() {
    this.isPlaying = false;
    if (this.currentTimeout) {
      clearTimeout(this.currentTimeout);
      this.currentTimeout = null;
    }
  }

  public setVolume(volume: number) {
    if (this.volumeNode && this.ctx) {
      // safe volume clamping between 0 and 0.4
      const safeVol = Math.max(0, Math.min(0.4, volume));
      this.volumeNode.gain.setValueAtTime(safeVol, this.ctx.currentTime);
    }
  }

  public togglePlay(onNoteChange?: (noteName: string) => void): boolean {
    if (this.isPlaying) {
      this.pause();
      return false;
    } else {
      this.play(onNoteChange);
      return true;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  // Generate a cute pop sound effect!
  public playPopSound() {
    this.initAudio();
    if (!this.ctx || !this.volumeNode) return;
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sine';
    // Frequency sweeps upwards quickly for a bubbly cute "pop" sound
    osc.frequency.setValueAtTime(250, now);
    osc.frequency.exponentialRampToValueAtTime(800, now + 0.12);

    gainNode.gain.setValueAtTime(0.3, now);
    gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.15);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination); // Bypass loop volume node to sound crisp

    osc.start();
    osc.stop(now + 0.16);
  }

  // Generate a cute sparkly chime sound for candles
  public playChimeSound() {
    this.initAudio();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    const now = this.ctx.currentTime;
    
    // Play a nice arpeggio of three chime notes
    const playNote = (freq: number, delay: number) => {
      const osc = this.ctx!.createOscillator();
      const gainNode = this.ctx!.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + delay);

      gainNode.gain.setValueAtTime(0, now + delay);
      gainNode.gain.linearRampToValueAtTime(0.2, now + delay + 0.02);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.5);

      osc.connect(gainNode);
      gainNode.connect(this.ctx!.destination);

      osc.start(now + delay);
      osc.stop(now + delay + 0.6);
    };

    playNote(523.25, 0);      // C5
    playNote(659.25, 0.08);   // E5
    playNote(783.99, 0.16);   // G5
    playNote(1046.50, 0.24);  // C6
  }
}
