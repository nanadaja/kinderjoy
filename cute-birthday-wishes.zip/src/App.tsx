import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Music, Sparkles, Share2, Heart, PartyPopper, Calendar, 
  User, RefreshCw, Gift, Moon, Star, Volume2, VolumeX, Eye
} from 'lucide-react';

import { BirthdayConfig, PHOTO_PRESETS } from './types';
import { BirthdaySynth } from './utils/audioSynth';
import { OpeningScreen } from './components/OpeningScreen';
import { CakeSection } from './components/CakeSection';
import { GallerySection } from './components/GallerySection';
import { CustomizerModal } from './components/CustomizerModal';
import { ParticleLayer } from './components/ParticleLayer';

// Instantiate the single-instance audio synthesizer
const synth = new BirthdaySynth();

const DEFAULT_CONFIG: BirthdayConfig = {
  recipientName: 'Rania Anindita ✨',
  senderName: 'Sahabat Terbaikmu 💖',
  message: 'Selamat ulang tahun! Semoga di hari yang istimewa ini, hidupmu dipenuhi dengan tawa, kebahagiaan, dan segala berkat yang melimpah. Terima kasih sudah selalu menjadi teman yang luar biasa! Tetaplah bersinar seperti bintang tercantik di langit malam. 🎂🌟',
  date: '15 Juli 2026',
  photos: [
    PHOTO_PRESETS['ewi-5'].url,
    PHOTO_PRESETS['cake'].url,
    PHOTO_PRESETS['bear-balloon'].url,
  ],
  presetMusicTempo: 125,
  themeColor: 'blue',
};

const getInitialConfig = (): BirthdayConfig => {
  try {
    const params = new URLSearchParams(window.location.search);
    const giftParam = params.get('gift');
    if (giftParam) {
      const decoded = atob(giftParam);
      // UTF-8 safe decoding
      const decodedJson = decodeURIComponent(
        decoded
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      const parsed = JSON.parse(decodedJson);
      if (parsed && parsed.recipientName) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error decoding custom config from URL:', e);
  }

  // Fallback to localStorage
  try {
    const saved = localStorage.getItem('cute_birthday_config');
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {}

  return DEFAULT_CONFIG;
};

export default function App() {
  const [config, setConfig] = useState<BirthdayConfig>(DEFAULT_CONFIG);
  const [isOpened, setIsOpened] = useState(false);
  const [isPlayingMusic, setIsPlayingMusic] = useState(false);
  const [currentNote, setCurrentNote] = useState('🎵');
  const [burstCount, setBurstCount] = useState(0);
  const [balloonCount, setBalloonCount] = useState(0);
  const [isCustomizerOpen, setIsCustomizerOpen] = useState(false);

  // Load initial config on mount
  useEffect(() => {
    const initialConfig = getInitialConfig();
    setConfig(initialConfig);
  }, []);

  // Update localStorage when config changes locally
  const handleSaveConfig = (newConfig: BirthdayConfig) => {
    setConfig(newConfig);
    try {
      localStorage.setItem('cute_birthday_config', JSON.stringify(newConfig));
    } catch (e) {}
  };

  // Toggle synth background music
  const handleToggleMusic = () => {
    const playing = synth.togglePlay((note) => {
      setCurrentNote(note);
    });
    setIsPlayingMusic(playing);
  };

  // Handle gift box open action
  const handleOpenGift = () => {
    // 1. Play cute pop sound
    synth.playPopSound();
    
    // 2. Short delay before main screen opens and music plays
    setTimeout(() => {
      setIsOpened(true);
      // Trigger music
      synth.play((note) => {
        setCurrentNote(note);
      });
      setIsPlayingMusic(true);
      // Auto trigger initial confetti
      setBurstCount((prev) => prev + 1);
    }, 400);
  };

  const handlePhotoChange = (index: number, newUrl: string) => {
    const nextPhotos = [...config.photos];
    nextPhotos[index] = newUrl;
    handleSaveConfig({
      ...config,
      photos: nextPhotos,
    });
    // Trigger little chimes to confirm
    synth.playChimeSound();
  };

  return (
    <main className="min-h-screen bg-[#050B1F] font-sans text-slate-100 relative overflow-x-hidden">
      {/* Background glowing gradients & Artistic Flair star elements */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none opacity-40">
        <div className="absolute -top-10 left-10 w-48 h-52 bg-blue-500 rounded-full opacity-25 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 right-10 w-52 h-64 bg-pink-500 rounded-full opacity-20 blur-3xl pointer-events-none" />

        {/* Wireframe Outline Circles */}
        <div className="absolute top-20 left-1/4 w-32 h-32 border-2 border-blue-400/20 rounded-full pointer-events-none" />
        <div className="absolute bottom-20 right-1/3 w-48 h-48 border-2 border-pink-400/10 rounded-full pointer-events-none" />

        {/* Twinkle Sparklers */}
        <div className="absolute top-10 left-10 text-blue-300 text-2xl animate-twinkle-star">✦</div>
        <div className="absolute top-1/4 right-20 text-blue-200 text-xl animate-twinkle-star" style={{ animationDelay: '1s' }}>★</div>
        <div className="absolute bottom-1/3 left-20 text-pink-300 text-lg animate-twinkle-star" style={{ animationDelay: '1.5s' }}>✦</div>
        <div className="absolute bottom-20 right-40 text-yellow-200 text-2xl animate-twinkle-star" style={{ animationDelay: '2s' }}>★</div>
        <div className="absolute top-20 right-1/4 w-3 h-3 bg-pink-400 rounded-full blur-sm" />
        <div className="absolute top-1/2 left-10 w-2 h-2 bg-blue-400 rounded-full blur-[1px]" />
      </div>

      {/* Starry Night particles background (ambient, absolute) */}
      <div className="absolute inset-0 pointer-events-none z-0">
        {[...Array(25)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-sky-200/40 animate-pulse"
            style={{
              width: Math.random() * 3 + 1.5 + 'px',
              height: Math.random() * 3 + 1.5 + 'px',
              top: Math.random() * 100 + '%',
              left: Math.random() * 100 + '%',
              animationDelay: Math.random() * 4 + 's',
              animationDuration: Math.random() * 3 + 2 + 's',
            }}
          />
        ))}
      </div>

      {/* Visual FX floating particles engine */}
      <ParticleLayer burstTrigger={burstCount} balloonTrigger={balloonCount} />

      <AnimatePresence mode="wait">
        {!isOpened ? (
          <motion.div
            key="cover"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 0.6, ease: 'easeInOut' }}
            className="relative z-10"
          >
            <OpeningScreen recipientName={config.recipientName} onOpen={handleOpenGift} />
          </motion.div>
        ) : (
          <motion.div
            key="content"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="relative z-10 w-full min-h-screen px-4 py-8 flex flex-col items-center justify-start pb-24"
          >
            {/* Top Toolbar / Music controller */}
            <div className="w-full max-w-md flex items-center justify-between mb-8 z-50">
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-full py-1.5 px-4 shadow-lg backdrop-blur-md">
                <Music className={`w-4 h-4 text-sky-300 ${isPlayingMusic ? 'animate-spin' : ''}`} style={{ animationDuration: '3s' }} />
                <span className="text-[11px] font-mono text-sky-200 font-bold tracking-wide">
                  {isPlayingMusic ? `Melody: ${currentNote}` : 'Musik Mati'}
                </span>
              </div>

              <div className="flex gap-2">
                {/* Music trigger */}
                <button
                  id="btn-music-toggle"
                  onClick={handleToggleMusic}
                  className="p-3 rounded-full bg-white/5 border border-white/10 hover:border-sky-400 text-sky-300 shadow-lg backdrop-blur-md active:scale-90 transition-all"
                  title="Putar Musik"
                >
                  {isPlayingMusic ? <Volume2 className="w-4 h-4 text-sky-300" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
                </button>

                {/* Edit Config FAB */}
                <button
                  id="btn-edit-config"
                  onClick={() => {
                    synth.playPopSound();
                    setIsCustomizerOpen(true);
                  }}
                  className="px-4 py-2 bg-gradient-to-r from-blue-400 to-pink-400 text-slate-950 font-bold text-xs rounded-full shadow-lg flex items-center gap-1.5 active:scale-95 transition-all"
                >
                  <Gift className="w-3.5 h-3.5" />
                  Kustomisasi 🎁
                </button>
              </div>
            </div>

            {/* Birthday Header Greeting */}
            <div className="text-center max-w-sm mb-8 flex flex-col items-center">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: 'spring', stiffness: 120, delay: 0.2 }}
                className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs font-bold text-sky-300 mb-4 shadow-md backdrop-blur-md"
              >
                <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                HAPPY BIRTHDAY TO YOU!
              </motion.div>

              {/* Spectacular gradient clipped name */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3, type: 'spring', stiffness: 100 }}
                className="relative inline-block mb-2"
              >
                <h1 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-200 via-pink-300 to-yellow-100 drop-shadow-[0_0_15px_rgba(147,197,253,0.5)] uppercase tracking-wide py-1">
                  {config.recipientName}
                </h1>
                <div className="absolute -top-4 -right-4 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center text-black text-sm rotate-12 shadow-md">🎂</div>
              </motion.div>

              {config.date && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.6 }}
                  transition={{ delay: 0.5 }}
                  className="text-xs text-sky-200 mt-1 font-medium flex items-center justify-center gap-1.5"
                >
                  <Calendar className="w-3.5 h-3.5 text-sky-400" />
                  {config.date}
                </motion.p>
              )}
            </div>

            {/* Custom wishes main message card - styled with Artistic Flair Glassmorphism */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-[35px] p-8 shadow-2xl max-w-md w-full mb-8 relative overflow-hidden"
            >
              {/* Glowing decorative border element */}
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 via-pink-400 to-yellow-300" />

              <div className="flex gap-1.5 text-yellow-300 mb-3">
                <Star className="w-4 h-4 fill-current animate-pulse" />
                <Star className="w-4 h-4 fill-current" />
                <Star className="w-4 h-4 fill-current" />
              </div>

              <p className="text-slate-100 leading-relaxed text-base whitespace-pre-line font-medium italic">
                "{config.message}"
              </p>

              {/* Sender signoff */}
              <div className="mt-6 flex items-center justify-end gap-1.5 border-t border-white/10 pt-4">
                <span className="text-xs text-slate-400 font-medium">Dari:</span>
                <span className="text-xs font-bold text-sky-200 bg-white/5 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 shadow-sm flex items-center gap-1">
                  <User className="w-3 h-3 text-sky-400" />
                  {config.senderName}
                  <Heart className="w-3 h-3 text-rose-400 fill-rose-400 animate-pulse" />
                </span>
              </div>
            </motion.div>

            {/* Interactive Elements: Balloon & Confetti Actions */}
            <div className="w-full max-w-md grid grid-cols-2 gap-3 mb-8">
              <button
                id="btn-letus-confetti"
                onClick={() => {
                  synth.playPopSound();
                  setBurstCount((prev) => prev + 1);
                }}
                className="py-3 px-4 bg-slate-900 border border-blue-500/10 hover:border-sky-400/40 rounded-2xl flex flex-col items-center justify-center gap-1.5 active:scale-95 transition-all shadow-lg select-none"
              >
                <span className="text-2xl">🎉</span>
                <span className="text-xs font-bold text-sky-200">Letuskan Confetti</span>
              </button>

              <button
                id="btn-kirim-balon"
                onClick={() => {
                  synth.playPopSound();
                  setBalloonCount((prev) => prev + 1);
                }}
                className="py-3 px-4 bg-slate-900 border border-blue-500/10 hover:border-indigo-400/40 rounded-2xl flex flex-col items-center justify-center gap-1.5 active:scale-95 transition-all shadow-lg select-none"
              >
                <span className="text-2xl">🎈</span>
                <span className="text-xs font-bold text-indigo-200">Kirim Balon Lucu</span>
              </button>
            </div>

            {/* Interactive Birthday Candle-blowing Section */}
            <div className="w-full max-w-md mb-8">
              <CakeSection
                recipientName={config.recipientName}
                onChime={() => synth.playChimeSound()}
                onConfetti={() => setBurstCount((prev) => prev + 1)}
              />
            </div>

            {/* Polaroid Photo Memory Gallery */}
            <div className="w-full max-w-md mb-8">
              <GallerySection photos={config.photos} onChangePhoto={handlePhotoChange} />
            </div>

            {/* Share action button at bottom */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="w-full max-w-md bg-gradient-to-tr from-sky-900/40 to-indigo-900/40 rounded-3xl p-5 border border-blue-500/20 shadow-xl flex items-center justify-between text-left mb-8 backdrop-blur-md"
            >
              <div>
                <h4 className="text-sm font-bold text-sky-200 flex items-center gap-1">
                  Bagikan Ucapan Ini! <Share2 className="w-3.5 h-3.5 text-indigo-400" />
                </h4>
                <p className="text-[11px] text-sky-300/80 mt-1 max-w-[220px]">
                  Buat QR Code dan bagikan link kado spesial versimu sendiri ke orang lain!
                </p>
              </div>

              <button
                id="btn-bagikan-ucapan-bawah"
                onClick={() => {
                  synth.playPopSound();
                  setIsCustomizerOpen(true);
                }}
                className="py-2.5 px-4 bg-sky-400 text-slate-950 font-bold text-xs rounded-xl shadow-md flex items-center gap-1 active:scale-95 transition-all"
              >
                Buka Panel 🎁
              </button>
            </motion.div>

            {/* Artistic Flair Footing layout */}
            <footer className="w-full max-w-md flex justify-between items-end mt-4 pt-6 border-t border-white/5 text-[10px] text-slate-500 font-mono">
              <div className="text-left">
                <p className="text-blue-300 uppercase opacity-60 tracking-wider">Hand-crafted with love 💖</p>
                <p className="text-white/80 font-medium">© {new Date().getFullYear()} - Sent with special love</p>
              </div>
              <div className="flex space-x-2 pb-1">
                <div className="w-2.5 h-2.5 bg-blue-400 rounded-full shadow-[0_0_8px_#60A5FA]"></div>
                <div className="w-2.5 h-2.5 bg-pink-400 rounded-full shadow-[0_0_8px_#F472B6]"></div>
                <div className="w-2.5 h-2.5 bg-yellow-400 rounded-full shadow-[0_0_8px_#FACC15]"></div>
              </div>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Settings Personalizer Customization Modal */}
      <CustomizerModal
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        currentConfig={config}
        onSave={handleSaveConfig}
      />
    </main>
  );
}
