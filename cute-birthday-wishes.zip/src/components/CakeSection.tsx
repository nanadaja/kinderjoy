import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, RotateCcw, HelpCircle } from 'lucide-react';

interface CakeSectionProps {
  onChime: () => void;
  onConfetti: () => void;
  recipientName: string;
}

export const CakeSection: React.FC<CakeSectionProps> = ({ onChime, onConfetti, recipientName }) => {
  // Candle states: index is candle ID, value is true if lit, false if blown out
  const [candles, setCandles] = useState<boolean[]>([true, true, true, true, true]);
  const [blownAll, setBlownAll] = useState(false);
  const [smokePuffs, setSmokePuffs] = useState<{ id: number; x: number; y: number }[]>([]);

  const handleBlowCandle = (index: number, e: React.MouseEvent) => {
    if (!candles[index]) return; // already blown out
    
    // Play chime sound
    onChime();

    // Spawn a puff of smoke at the click coordinates
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const newPuff = {
      id: Date.now(),
      x,
      y
    };
    setSmokePuffs(prev => [...prev, newPuff]);
    setTimeout(() => {
      setSmokePuffs(prev => prev.filter(p => p.id !== newPuff.id));
    }, 1200);

    // Update candle state
    const nextCandles = [...candles];
    nextCandles[index] = false;
    setCandles(nextCandles);

    // If all are blown out
    if (nextCandles.every(c => !c)) {
      setBlownAll(true);
      // Large celebratory explosion!
      setTimeout(() => {
        onConfetti();
      }, 300);
    }
  };

  const handleResetCandles = () => {
    setCandles([true, true, true, true, true]);
    setBlownAll(false);
    onChime();
  };

  return (
    <div id="cake-section" className="relative flex flex-col items-center bg-white/5 backdrop-blur-xl border border-white/10 rounded-[35px] p-6 md:p-8 shadow-2xl max-w-md w-full mx-auto">
      {/* Decorative starry badge */}
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-gradient-to-r from-blue-400 via-sky-400 to-pink-400 border border-white/10 text-slate-950 text-xs font-black uppercase tracking-wider rounded-full shadow-lg flex items-center gap-1">
        <Sparkles className="w-3.5 h-3.5" />
        Ritual Tiup Lilin Interaktif
      </div>

      <div className="text-center mt-2 mb-6">
        <h3 className="text-lg font-bold text-sky-200">
          {blownAll ? 'Yeeay! Lilin Padam! 🎉' : 'Tiup Lilinnya Yuk! 🎂'}
        </h3>
        <p className="text-xs text-sky-300/70 mt-1 max-w-[280px] mx-auto">
          {blownAll 
            ? 'Semua permohonanmu didengar! Semoga segala impianmu segera terwujud ya! ✨' 
            : 'Ketuk satu per satu api lilin di bawah untuk meniup dan memadamkannya!'}
        </p>
      </div>

      {/* Interactive Birthday Cake Container */}
      <div className="relative w-64 h-64 flex flex-col items-center justify-end select-none">
        {/* Absolute smoke puffs */}
        <div className="absolute inset-0 pointer-events-none z-30">
          <AnimatePresence>
            {smokePuffs.map(puff => (
              <motion.div
                key={puff.id}
                initial={{ opacity: 0.8, scale: 0.3, y: 0 }}
                animate={{ opacity: 0, scale: 2, y: -80, x: (Math.random() - 0.5) * 40 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1, ease: 'easeOut' }}
                className="absolute bg-slate-400/50 rounded-full blur-[2px] w-6 h-6"
                style={{ left: puff.x, top: puff.y }}
              />
            ))}
          </AnimatePresence>
        </div>

        {/* Candles row */}
        <div className="flex justify-center items-end gap-5 mb-[-4px] z-20 w-full px-8">
          {candles.map((isLit, idx) => (
            <div key={idx} className="relative flex flex-col items-center group">
              {/* Flame (clickable) */}
              <AnimatePresence>
                {isLit ? (
                  <motion.div
                    id={`candle-flame-${idx}`}
                    initial={{ scale: 0 }}
                    animate={{ 
                      scale: [1, 1.15, 0.9, 1.1, 1],
                      y: [0, -2, 1, -1, 0],
                      rotate: [0, -3, 3, -1, 0]
                    }}
                    exit={{ scale: 0, y: -10, opacity: 0 }}
                    transition={{ 
                      duration: 1.5,
                      repeat: Infinity,
                      repeatType: 'reverse',
                      ease: 'easeInOut'
                    }}
                    onClick={(e) => handleBlowCandle(idx, e)}
                    className="cursor-pointer relative w-5 h-8 flex items-end justify-center group"
                  >
                    {/* Inner core flame */}
                    <div className="absolute w-3.5 h-6 bg-gradient-to-t from-red-500 via-yellow-400 to-yellow-100 rounded-full blur-[1px] shadow-[0_0_10px_rgba(239,68,68,0.7)]" />
                    {/* Extra warm aura */}
                    <div className="absolute w-6 h-6 bg-orange-400/30 rounded-full blur-md animate-pulse" />
                  </motion.div>
                ) : (
                  // Small burnt wick
                  <div className="w-1 h-3 bg-slate-600 rounded-t-sm mb-1" />
                )}
              </AnimatePresence>

              {/* Candle Body */}
              <div 
                className={`w-3 h-12 rounded-t-sm transition-all duration-300 ${
                  isLit 
                    ? 'bg-gradient-to-b from-sky-300 via-sky-400 to-blue-500 border border-sky-200/50' 
                    : 'bg-gradient-to-b from-slate-500 to-slate-700 opacity-60'
                }`}
                style={{
                  boxShadow: isLit ? '0 0 8px rgba(56,189,248,0.4)' : 'none'
                }}
              >
                {/* Cute candy stripes on candles */}
                <div className="w-full h-full opacity-30 bg-[repeating-linear-gradient(45deg,#fff,#fff_2px,transparent_2px,transparent_6px)]" />
              </div>
            </div>
          ))}
        </div>

        {/* 2D Vector Cute Cake Layers */}
        {/* Top Cake Layer */}
        <div className="relative w-44 h-14 bg-gradient-to-b from-sky-400 to-indigo-600 rounded-t-2xl border-t-2 border-sky-300 shadow-inner flex flex-col justify-between overflow-hidden z-10">
          {/* Dripping frosting effect */}
          <div className="flex justify-between w-full mt-[-2px] h-6 text-sky-200 fill-current">
            {[...Array(9)].map((_, i) => (
              <svg key={i} className="w-6 h-6 -mx-1" viewBox="0 0 24 24">
                <path d="M12,2C18,2 20,8 20,12C20,16 16,18 12,18C8,18 4,16 4,12C4,8 6,2 12,2Z" />
              </svg>
            ))}
          </div>
          {/* Adorable stars decoration */}
          <div className="flex justify-around items-center px-4 mb-2">
            <span className="text-yellow-300 text-xs animate-bounce" style={{ animationDelay: '0.2s' }}>★</span>
            <span className="text-rose-300 text-xs animate-bounce" style={{ animationDelay: '0.5s' }}>❤</span>
            <span className="text-yellow-300 text-xs animate-bounce" style={{ animationDelay: '0.8s' }}>★</span>
          </div>
        </div>

        {/* Middle Plate / Cream Layer */}
        <div className="w-48 h-2 bg-indigo-300/80 rounded-full z-10" />

        {/* Bottom Cake Layer */}
        <div className="relative w-52 h-18 bg-gradient-to-b from-sky-500 to-indigo-700 rounded-t-xl border-t border-sky-300/50 shadow-md flex justify-around items-end pb-3 overflow-hidden">
          {/* Bottom frosting wave */}
          <div className="absolute top-0 w-full h-4 bg-sky-200/20" />
          {/* Little strawberry-like cartoon buttons */}
          <div className="w-4 h-4 rounded-full bg-rose-400 shadow-md animate-pulse" />
          <div className="w-4 h-4 rounded-full bg-yellow-400 shadow-md animate-pulse" style={{ animationDelay: '0.3s' }} />
          <div className="w-4 h-4 rounded-full bg-pink-400 shadow-md animate-pulse" style={{ animationDelay: '0.6s' }} />
          <div className="w-4 h-4 rounded-full bg-emerald-400 shadow-md animate-pulse" style={{ animationDelay: '0.9s' }} />
        </div>

        {/* Plate Base */}
        <div className="w-60 h-4 bg-slate-300 rounded-full shadow-[0_5px_15px_rgba(0,0,0,0.4)] border-b-4 border-slate-400" />
      </div>

      {/* Actions and Wishes Dialog */}
      <div className="mt-8 w-full flex flex-col items-center">
        {blownAll ? (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex flex-col items-center bg-white/5 backdrop-blur-md border border-white/10 p-5 rounded-2xl w-full text-center"
          >
            <div className="w-12 h-12 rounded-full bg-yellow-400/10 flex items-center justify-center mb-2 animate-bounce">
              <Sparkles className="w-6 h-6 text-yellow-300" />
            </div>
            <p className="text-sm font-bold text-sky-200">Semoga Panjang Umur & Bahagia Selalu!</p>
            <p className="text-xs text-sky-300/80 mt-1">Make a wish: {recipientName || 'Kamu'} adalah orang yang luar biasa! 🌟</p>
            
            <button
              id="btn-reset-lilin"
              onClick={handleResetCandles}
              className="mt-4 px-5 py-2 bg-gradient-to-r from-blue-400 to-pink-400 text-slate-950 text-xs font-bold rounded-full flex items-center gap-1.5 active:scale-95 transition-all uppercase tracking-wider"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Nyalakan Lilin Lagi
            </button>
          </motion.div>
        ) : (
          <button
            id="btn-tiup-semua"
            onClick={() => {
              setCandles([false, false, false, false, false]);
              setBlownAll(true);
              onChime();
              onConfetti();
            }}
            className="px-6 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-sky-200 text-xs font-bold rounded-full flex items-center gap-2 active:scale-95 transition-all shadow-md uppercase tracking-wider"
          >
            💨 Tiup Semua Sekaligus
          </button>
        )}
      </div>
    </div>
  );
};
